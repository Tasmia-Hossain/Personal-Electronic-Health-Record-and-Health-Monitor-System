/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package healthapp;

import java.util.prefs.Preferences;

/**
 *
 * @author Abu Dozana Tahmid
 */
public class Settings {
     private static final String KEEP_SIGNED_IN_KEY = "keepSignedIn";
    private static final String LAST_LOGGED_IN_USERNAME_KEY = "lastLoggedInUsername";

    private Preferences preferences;

    public Settings() {
        preferences = Preferences.userNodeForPackage(getClass());
    }

    public boolean isKeepMeSignedIn() {
        return preferences.getBoolean(KEEP_SIGNED_IN_KEY, false);
    }

    public void setKeepMeSignedIn(boolean keepMeSignedIn) {
        preferences.putBoolean(KEEP_SIGNED_IN_KEY, keepMeSignedIn);
    }

    public String getLastLoggedInUsername() {
        return preferences.get(LAST_LOGGED_IN_USERNAME_KEY, "");
    }

    public void setLastLoggedInUsername(String username) {
        preferences.put(LAST_LOGGED_IN_USERNAME_KEY, username);
    }
}
