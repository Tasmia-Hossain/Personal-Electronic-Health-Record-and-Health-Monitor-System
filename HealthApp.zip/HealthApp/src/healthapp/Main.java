package healthapp;

public class Main {

    public static void main(String[] args) {


         // Load settings
        Settings settings = new Settings();
        boolean keepSignedIn = settings.isKeepMeSignedIn();
        String lastLoggedInUsername = settings.getLastLoggedInUsername();

        if (keepSignedIn && !lastLoggedInUsername.isEmpty()) {
            // Automatically log in the user and show the dashboard
           Dashboard dashboardFrame = new Dashboard(lastLoggedInUsername);
            dashboardFrame.setVisible(true);
            dashboardFrame.pack();
            dashboardFrame.setLocationRelativeTo(null);
        } else {
            // Show the login screen
            Login loginFrame = new Login();
            loginFrame.setVisible(true);
            loginFrame.pack();
            loginFrame.setLocationRelativeTo(null);
        }

    }

}