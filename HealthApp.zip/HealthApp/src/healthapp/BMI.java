
package healthapp;
import java.awt.Component;
import java.awt.Font;
import static java.lang.String.format;
import javax.swing.JTable;

import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;


public class BMI extends javax.swing.JFrame {
    
    public double weight=0.0d,height=0.0d,bmi=0.0d;
    public BMI() {
        initComponents();
        customizeTableHeader();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel8 = new javax.swing.JLabel();
        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        ClearButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        WeightBox = new javax.swing.JTextField();
        HeightBox = new javax.swing.JTextField();
        CalculateButton = new javax.swing.JButton();
        kgButton = new javax.swing.JRadioButton();
        lbsButton = new javax.swing.JRadioButton();
        inchesButton = new javax.swing.JRadioButton();
        cmButton = new javax.swing.JRadioButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        BMIBox = new javax.swing.JTextField();
        BackButton = new javax.swing.JButton();
        BMIStatus = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        BMITable = new javax.swing.JTable();

        jLabel8.setText("jLabel8");

        setTitle("BMI calculator");
        setPreferredSize(new java.awt.Dimension(780, 500));
        setResizable(false);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 0, 0));
        jLabel1.setText("BMI");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 30, 102, 55));

        ClearButton.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        ClearButton.setText("Clear");
        ClearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClearButtonActionPerformed(evt);
            }
        });
        getContentPane().add(ClearButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 420, -1, -1));

        jLabel2.setFont(new java.awt.Font("Verdana", 1, 24)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 51, 153));
        jLabel2.setText("BODY MASS INDEX CALCULATOR");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 40, -1, -1));

        jLabel3.setFont(new java.awt.Font("Segoe UI Symbol", 1, 18)); // NOI18N
        jLabel3.setText("Enter your data");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, -1, -1));

        jLabel4.setFont(new java.awt.Font("Segoe UI Symbol", 1, 18)); // NOI18N
        jLabel4.setText("Weight :");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 170, -1, -1));

        jLabel5.setFont(new java.awt.Font("Segoe UI Symbol", 1, 18)); // NOI18N
        jLabel5.setText("Height : ");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 220, -1, -1));

        WeightBox.setFont(new java.awt.Font("Segoe UI Symbol", 1, 18)); // NOI18N
        WeightBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                WeightBoxActionPerformed(evt);
            }
        });
        getContentPane().add(WeightBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 160, 83, -1));

        HeightBox.setFont(new java.awt.Font("Segoe UI Symbol", 1, 18)); // NOI18N
        getContentPane().add(HeightBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 210, 83, -1));

        CalculateButton.setFont(new java.awt.Font("Segoe UI Symbol", 1, 18)); // NOI18N
        CalculateButton.setText("Calculate BMI");
        CalculateButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CalculateButtonActionPerformed(evt);
            }
        });
        getContentPane().add(CalculateButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 280, -1, -1));

        buttonGroup1.add(kgButton);
        kgButton.setFont(new java.awt.Font("Segoe UI Symbol", 1, 18)); // NOI18N
        kgButton.setSelected(true);
        kgButton.setText("kg");
        getContentPane().add(kgButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 160, -1, -1));

        buttonGroup1.add(lbsButton);
        lbsButton.setFont(new java.awt.Font("Segoe UI Symbol", 1, 18)); // NOI18N
        lbsButton.setText("lbs");
        lbsButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lbsButtonActionPerformed(evt);
            }
        });
        getContentPane().add(lbsButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 160, 98, -1));

        buttonGroup2.add(inchesButton);
        inchesButton.setFont(new java.awt.Font("Segoe UI Symbol", 1, 18)); // NOI18N
        inchesButton.setSelected(true);
        inchesButton.setText("inches");
        getContentPane().add(inchesButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 210, -1, -1));

        buttonGroup2.add(cmButton);
        cmButton.setFont(new java.awt.Font("Segoe UI Symbol", 1, 18)); // NOI18N
        cmButton.setText("cm");
        cmButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cmButtonActionPerformed(evt);
            }
        });
        getContentPane().add(cmButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 210, 98, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI Symbol", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 51, 153));
        jLabel6.setText("BMI Table");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 100, 96, -1));

        jLabel7.setFont(new java.awt.Font("Segoe UI Symbol", 1, 24)); // NOI18N
        jLabel7.setText("BMI :");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 350, 59, -1));

        BMIBox.setEditable(false);
        BMIBox.setFont(new java.awt.Font("Segoe UI Symbol", 1, 24)); // NOI18N
        BMIBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BMIBoxActionPerformed(evt);
            }
        });
        getContentPane().add(BMIBox, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 350, 90, -1));

        BackButton.setFont(new java.awt.Font("Tahoma", 1, 16)); // NOI18N
        BackButton.setText("Back");
        BackButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackButtonActionPerformed(evt);
            }
        });
        getContentPane().add(BackButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 420, -1, -1));

        BMIStatus.setEditable(false);
        BMIStatus.setFont(new java.awt.Font("Segoe UI Symbol", 1, 24)); // NOI18N
        BMIStatus.setForeground(new java.awt.Color(255, 0, 51));
        BMIStatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BMIStatusActionPerformed(evt);
            }
        });
        getContentPane().add(BMIStatus, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 350, 200, -1));

        jScrollPane1.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        jScrollPane1.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER);

        BMITable.setBackground(new java.awt.Color(204, 204, 255));
        BMITable.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));
        BMITable.setFont(new java.awt.Font("Segoe UI Symbol", 1, 14)); // NOI18N
        BMITable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {"<18.5", "Underweight"},
                {"18.5 - 24.9", "Normal range"},
                {"25.0 - 29.9", "Overweight"},
                {"≥30", "Obese"},
                {"30.0 - 34.9", "Obese class I"},
                {"35.0 - 39.9", "Obese class II"},
                {"≥40", "Obese class III"}
            },
            new String [] {
                "BMI", "Weight Status"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        BMITable.setAutoscrolls(false);
        BMITable.setEnabled(false);
        BMITable.setFocusable(false);
        BMITable.setGridColor(new java.awt.Color(0, 0, 0));
        BMITable.setMaximumSize(new java.awt.Dimension(30, 30));
        BMITable.setMinimumSize(new java.awt.Dimension(30, 30));
        BMITable.setPreferredSize(new java.awt.Dimension(150, 154));
        BMITable.setRequestFocusEnabled(false);
        BMITable.setRowHeight(22);
        BMITable.setRowSelectionAllowed(false);
        BMITable.setShowGrid(true);
        BMITable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(BMITable);
        if (BMITable.getColumnModel().getColumnCount() > 0) {
            BMITable.getColumnModel().getColumn(0).setResizable(false);
            BMITable.getColumnModel().getColumn(1).setResizable(false);
        }

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 130, 240, 180));

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void customizeTableHeader() {
    JTableHeader header = BMITable.getTableHeader();
    
    Font tableFont = BMITable.getFont();
    Font headerFont = new Font(tableFont.getName(), Font.BOLD, tableFont.getSize());
    
    header.setFont(headerFont);
    header.setDefaultRenderer(new DefaultTableCellRenderer() {
        @Override
        public Component getTableCellRendererComponent(
                JTable table, Object value,
                boolean isSelected, boolean hasFocus,
                int row, int column) {
            super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
            setHorizontalAlignment(CENTER);
            return this;
        }
    });
}

    private void WeightBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_WeightBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_WeightBoxActionPerformed

    private void cmButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cmButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cmButtonActionPerformed

    private void BMIStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BMIStatusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BMIStatusActionPerformed

    private void ClearButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClearButtonActionPerformed
        WeightBox.setText("");
        HeightBox.setText("");
        BMIBox.setText("");
        BMIStatus.setText("");
    }//GEN-LAST:event_ClearButtonActionPerformed

    private void CalculateButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CalculateButtonActionPerformed
        weight=Double.parseDouble(WeightBox.getText());
        height=Double.parseDouble(HeightBox.getText());
        
        if(lbsButton.isSelected()){
            weight=weight/2.205;
        }
        if(inchesButton.isSelected()){
            height=height/39.37;
        }else if(cmButton.isSelected()){
            height=height/100;
        }
        bmi=weight/(height*height);
        System.out.println(bmi);
        if(bmi<18){
            BMIBox.setText(format("%.2f",bmi));
            BMIStatus.setText(format("Underweight"));
        }else if(bmi>=18.5&&bmi<=24.9){
            BMIBox.setText(format("%.2f",bmi));
            BMIStatus.setText(format("Normal Range"));
        }else if(bmi>=25.0&&bmi<=29.9){
            BMIBox.setText(format("%.2f",bmi));
            BMIStatus.setText(format("Overweight"));
        }else if(bmi>=30.0&&bmi<=34.9){
            BMIBox.setText(format("%.2f",bmi));
            BMIStatus.setText(format("Obese class I"));
        }else if(bmi>=35.0&&bmi<=39.9){
            BMIBox.setText(format("%.2f",bmi));
            BMIStatus.setText(format("Obese class II"));
        }else if(bmi>=40){
            BMIBox.setText(format("%.2f",bmi));
            BMIStatus.setText(format("Obese class III"));
        }
    }//GEN-LAST:event_CalculateButtonActionPerformed

    private void lbsButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lbsButtonActionPerformed
        
    }//GEN-LAST:event_lbsButtonActionPerformed

    private void BackButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackButtonActionPerformed
        setVisible(false);
       // this.dispose();
    }//GEN-LAST:event_BackButtonActionPerformed

    private void BMIBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BMIBoxActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BMIBoxActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BMI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BMI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BMI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BMI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BMI().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField BMIBox;
    private javax.swing.JTextField BMIStatus;
    private javax.swing.JTable BMITable;
    private javax.swing.JButton BackButton;
    private javax.swing.JButton CalculateButton;
    private javax.swing.JButton ClearButton;
    private javax.swing.JTextField HeightBox;
    private javax.swing.JTextField WeightBox;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JRadioButton cmButton;
    private javax.swing.JRadioButton inchesButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JRadioButton kgButton;
    private javax.swing.JRadioButton lbsButton;
    // End of variables declaration//GEN-END:variables
}
