/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package healthapp;

import java.awt.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Admin
 */

public class UserTableClass {
    static HashMap<Integer,String>x = new HashMap<>();
    static HashMap<Integer,Integer>matchedDisease = new HashMap<Integer,Integer>();
    double possiblity;
    ArrayList<String> fastAidSuggestion = new ArrayList<>();
    public  ArrayList db(ArrayList<String> symtomList) throws ClassNotFoundException, SQLException{
     Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        
            // Step 1: Load and register the SQLite JDBC driver
            Class.forName("org.sqlite.JDBC");

            // Step 2: Establish a connection to the database
            String dbUrl = "jdbc:sqlite:src/database/HealthAppDB.db";
            connection = DriverManager.getConnection(dbUrl);

            // Step 3: Create a statement
            statement = connection.createStatement();

            // Step 4: Execute a query
            String query = "SELECT * FROM DiseaseTable";
            resultSet = statement.executeQuery(query);
        ResultSet z = statement.executeQuery(query);
        // Step 5: Process the results
            
            
            while (resultSet.next()) {
                
                int id = resultSet.getInt("DiseaseID");
                String diseaseSymtoms = resultSet.getString("DiseaseSymptomps");
               
                
                String diseaseName = resultSet.getString("DiseaseName");
                x.put(id, diseaseName);
                // Process the retrieved data
                HashMap<String,Integer> diseaseMap = new HashMap<String,Integer>();
                String ithSymtom="";
                diseaseSymtoms+=",";
                
                for(int i=0;i<diseaseSymtoms.length();++i){

                    if (diseaseSymtoms.charAt(i)==','){
                        
                        ithSymtom=ithSymtom.replace(" ", "");
                        diseaseMap.put(ithSymtom,0);
                        ithSymtom="";
                    }
                    else{
                        //ithSymtom.replace(" ", "");
                        ithSymtom+=diseaseSymtoms.charAt(i);
                    }
                }
                int matchedSymtoms=0;
                
                for(int i=0;i<symtomList.size();++i){
                    String v =symtomList.get(i);
                    v = v.replace(" ", "");
                    if(diseaseMap.containsKey(v)){
                        
                        matchedSymtoms++;
                    }
                    
                }
             matchedDisease.put(id,matchedSymtoms);
             
             
            }
            
            
            try {
            if (connection != null) {
                connection.close();
                resultSet.close();
                statement.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
                    
            

        System.out.println(matchedDisease);
        ArrayList<ArrayList<Integer>>diseaseSort = new ArrayList<>();
        
        for (Map.Entry<Integer, Integer> entry :matchedDisease.entrySet()){
                    ArrayList<Integer>t = new ArrayList<>();

            int freq = entry.getValue();
            int index = entry.getKey();
            t.add(freq);
            t.add(index);
            diseaseSort.add(t);
        }
                Collections.sort(diseaseSort, Comparator.comparingInt(inner -> inner.get(0)));

                Collections.reverse(diseaseSort);
                System.out.println(diseaseSort);
                return diseaseSort;
                
 }
 
        String getDiseaseName(int index){
            return x.get(index);
        }
        
        
             
        ArrayList firstAidScene(String userDisease,int totalInput) throws ClassNotFoundException, SQLException{
            
            Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        
            // Step 1: Load and register the SQLite JDBC driver
            Class.forName("org.sqlite.JDBC");

            // Step 2: Establish a connection to the database
            String dbUrl = "jdbc:sqlite:src/database/HealthAppDB.db";
            connection = DriverManager.getConnection(dbUrl);

            // Step 3: Create a statement
            statement = connection.createStatement();

            // Step 4: Execute a query
            String query = "SELECT * FROM DiseaseTable";
            resultSet = statement.executeQuery(query);
            
            while(resultSet.next()){
                String diseaseName = resultSet.getString("DiseaseName");
                String firstAidSpray = resultSet.getString("FastAid");
                int diseaseId = resultSet.getInt("DiseaseID");
                if(diseaseName.equals(userDisease)){  
                    System.out.println("DiseaseId"+diseaseId);
                    System.out.println(matchedDisease);
                    double lob=0;
                    if(!matchedDisease.isEmpty())
                     lob= matchedDisease.get(diseaseId);

                    System.out.println(lob+"  / "+totalInput);
                    //possiblity = (lob/totalInput)*100;
                    
                    possiblity = (lob/totalInput)*100;
                    System.out.println(possiblity+"MW");
                    
                    int i =0;
                    String str="";
                    
                    while(i<firstAidSpray.length()){
                        if(firstAidSpray.charAt(i)=='.'||firstAidSpray.charAt(i)==','){
                            fastAidSuggestion.add(str);
                            str="";
                            i+=2;
                        }
                        else{
                            str+=firstAidSpray.charAt(i);
                            i+=1;
                        }
                        
                    }
                    System.out.println(fastAidSuggestion);
                    NewJFrame1 firstAidFrame = new NewJFrame1 ();
                    firstAidFrame.setAidListFixed(fastAidSuggestion);
                    return fastAidSuggestion;
                    
                }
            }
            try {
            if (connection != null) {
                connection.close();
                statement.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
            
            return null;
        }
        
        double getPossiblity(){
            
            return possiblity;
        }
       }