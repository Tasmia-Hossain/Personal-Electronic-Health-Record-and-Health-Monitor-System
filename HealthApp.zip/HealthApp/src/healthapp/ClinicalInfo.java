/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package healthapp;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Date;
import javax.swing.table.DefaultTableModel;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class ClinicalInfo extends javax.swing.JPanel {

    /**
     * Creates new form ClinicalInfo
     */
    private DefaultTableModel model;
    private DefaultTableModel model2;

    public ClinicalInfo() {
        initComponents();

        model = (DefaultTableModel) jTable2.getModel();
        model2 = (DefaultTableModel) mtable.getModel();
        loadTable();
        loadmtable();
    }

    public class DatabaseConnection {

    public static Connection connect() {
        Connection conn = null;

        try {
            String url = "jdbc:sqlite:src/database/HealthAppDB.db";
            conn = DriverManager.getConnection(url);

            // Create the family_disease table if it doesn't exist
            String createFamilyDiseaseTableSQL = "CREATE TABLE IF NOT EXISTS family_disease ("
                    + "Relation TEXT, "
                    + "[Disease Name] TEXT, "
                    + "Generation TEXT)";

            // Create the medical_history table if it doesn't exist
            String createMedicalHistoryTableSQL = "CREATE TABLE IF NOT EXISTS medical_history ("
                    + "ID INTEGER PRIMARY KEY, "
                    + "Symptoms TEXT, "
                    + "Date TEXT, "
                    + "PrescribedMedicine TEXT)";

            try (PreparedStatement pstmt1 = conn.prepareStatement(createFamilyDiseaseTableSQL);
                 PreparedStatement pstmt2 = conn.prepareStatement(createMedicalHistoryTableSQL)) {
                pstmt1.executeUpdate();
                pstmt2.executeUpdate();
            }

            System.out.println("Connection to SQLite has been established.");
        } catch (SQLException e) {
            System.out.println("Connection error: " + e.getMessage());
        }
        return conn;
    }
}

    private void loadTable() {
        model.setRowCount(0); // Clear existing data
        String sql = "SELECT * FROM family_disease";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:src/database/HealthAppDB.db"); PreparedStatement pstmt = conn.prepareStatement(sql); ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                String relation = rs.getString("Relation");
                String diseaseName = rs.getString("Disease Name"); // Use the appropriate column name
                String generation = rs.getString("Generation");
                model.addRow(new Object[]{relation, diseaseName, generation});
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    private void loadmtable() {
        model2.setRowCount(0); // Clear existing data
        String sql = "SELECT * FROM medical_history";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:src/database/HealthAppDB.db"); PreparedStatement pstmt = conn.prepareStatement(sql); ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("ID");
                String symptoms = rs.getString("Symptoms");
                String date = rs.getString("Date");
                String prescribedMedicine = rs.getString("PrescribledMedicine");
                model2.addRow(new Object[]{id, symptoms, date, prescribedMedicine});
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        symptomsTextField = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        mtable = new javax.swing.JTable();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        dateTextField = new com.toedter.calendar.JDateChooser();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        relationTextField = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        diseaseNameTextField2 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        generationTextFIeld = new javax.swing.JTextField();
        addRowButton = new javax.swing.JButton();
        deleteRowButton = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        prescribedMedicineTextField = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        addMtablerow = new javax.swing.JButton();
        deleteMtablerow = new javax.swing.JButton();

        setToolTipText("");
        setPreferredSize(new java.awt.Dimension(884, 620));
        setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("Clinical Information");
        add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 10, 570, -1));

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Medical History");
        add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 49, -1, -1));
        add(symptomsTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 80, 240, -1));

        mtable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Symptoms", "Date", "Medicine"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Object.class, java.lang.Object.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        jScrollPane1.setViewportView(mtable);

        add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 225, 410, 360));

        jSeparator1.setOrientation(javax.swing.SwingConstants.VERTICAL);
        add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 60, 15, 550));

        jLabel4.setText("Enter Symptoms");
        add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, -1, -1));

        jLabel5.setText("Date");
        add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 110, -1, -1));
        add(dateTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 110, 240, -1));

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setText("Family Genetical Disease History");
        add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 80, -1, -1));

        jLabel7.setText("Relation");
        add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 110, -1, -1));

        relationTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                relationTextFieldActionPerformed(evt);
            }
        });
        add(relationTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 110, 168, -1));

        jLabel8.setText("Disease Name");
        add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 150, -1, -1));

        diseaseNameTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                diseaseNameTextField2ActionPerformed(evt);
            }
        });
        add(diseaseNameTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 150, 137, -1));

        jLabel9.setText("Generation");
        add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 190, -1, -1));
        add(generationTextFIeld, new org.netbeans.lib.awtextra.AbsoluteConstraints(550, 190, 153, -1));

        addRowButton.setText("Add");
        addRowButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addRowButtonActionPerformed(evt);
            }
        });
        add(addRowButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 110, -1, -1));

        deleteRowButton.setText("Delete");
        deleteRowButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteRowButtonActionPerformed(evt);
            }
        });
        add(deleteRowButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(720, 150, -1, -1));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Relation (by Blood)", "Disease Name", "Generation"
            }
        ));
        jScrollPane2.setViewportView(jTable2);

        add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 240, 410, 350));

        prescribedMedicineTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                prescribedMedicineTextFieldActionPerformed(evt);
            }
        });
        add(prescribedMedicineTextField, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 150, 240, -1));

        jLabel10.setText("Prescribed Medicine");
        add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 150, 110, -1));

        addMtablerow.setText("Add");
        addMtablerow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addMtablerowActionPerformed(evt);
            }
        });
        add(addMtablerow, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 190, -1, -1));

        deleteMtablerow.setText("Delete");
        deleteMtablerow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteMtablerowActionPerformed(evt);
            }
        });
        add(deleteMtablerow, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 190, -1, -1));
    }// </editor-fold>//GEN-END:initComponents

    private void refreshTable() {
        DefaultTableModel tableModel = (DefaultTableModel) mtable.getModel();
        tableModel.setRowCount(0); // Clear existing rows

        Connection connection = null;
        Statement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DriverManager.getConnection("jdbc:sqlite:src/database/HealthAppDB.db");
            String query = "SELECT * FROM medical_history";
            statement = connection.createStatement();
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                int id = resultSet.getInt("ID");
                String diseaseName = resultSet.getString("Disease Name");
                long timestamp = resultSet.getLong("Date"); // Retrieve timestamp
                Date date = new Date(timestamp); // Convert timestamp to Date
                Object[] rowData = {id, diseaseName, date};
                tableModel.addRow(rowData);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) {
                    resultSet.close();
                }
                if (statement != null) {
                    statement.close();
                }
                if (connection != null) {
                    connection.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    private byte[] readImageData(File file) {
        try (InputStream inputStream = new FileInputStream(file)) {
            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
            int bufferSize = 1024;
            byte[] buffer = new byte[bufferSize];
            int bytesRead;

            while ((bytesRead = inputStream.read(buffer)) != -1) {
                byteArrayOutputStream.write(buffer, 0, bytesRead);
            }

            return byteArrayOutputStream.toByteArray();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    private int selectedRowID() {
        int selectedRow = mtable.getSelectedRow();
        if (selectedRow != -1) {
            // Assuming the ID is stored in the first column (index 0) of the table
            return (int) mtable.getValueAt(selectedRow, 0);
        } else {
            return -1; // Return a value that indicates no row is selected
        }
    }

    private void relationTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_relationTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_relationTextFieldActionPerformed

    private void diseaseNameTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_diseaseNameTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_diseaseNameTextField2ActionPerformed

    private void deleteRowButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteRowButtonActionPerformed
        // TODO add your handling code here:
        int selectedRow = jTable2.getSelectedRow();

        if (selectedRow == -1) {
            System.out.println("No row selected.");
            return;
        }

        String relation = (String) model.getValueAt(selectedRow, 0);
        String diseaseName = (String) model.getValueAt(selectedRow, 1);
        String generation = (String) model.getValueAt(selectedRow, 2);

        String sql = "DELETE FROM family_disease WHERE Relation = ? AND [Disease Name] = ? AND Generation = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:src/database/HealthAppDB.db"); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, relation);
            pstmt.setString(2, diseaseName);
            pstmt.setString(3, generation);

            pstmt.executeUpdate();

            System.out.println("Data deleted from the database.");

            // Remove the selected row from the table model
            model.removeRow(selectedRow);
        } catch (SQLException e) {
            System.out.println("Error deleting data: " + e.getMessage());
        }
    }//GEN-LAST:event_deleteRowButtonActionPerformed

    private void addRowButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addRowButtonActionPerformed
        // TODO add your handling code here:
      String relation = relationTextField.getText();
        String diseaseName = diseaseNameTextField2.getText();
        String generation = generationTextFIeld.getText();

        String sql = "INSERT INTO family_disease(Relation, [Disease Name], Generation) VALUES(?,?,?)";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:src/database/HealthAppDB.db"); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, relation);
            pstmt.setString(2, diseaseName);
            pstmt.setString(3, generation);

            pstmt.executeUpdate();

            System.out.println("Data added to the database.");

            // Refresh the table (if required)
            model.addRow(new Object[]{relation, diseaseName, generation});
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }


    }//GEN-LAST:event_addRowButtonActionPerformed

    private void addMtablerowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addMtablerowActionPerformed
        // TODO add your handling code here:
          String symptoms = symptomsTextField.getText();
        String date = dateTextField.getDateFormatString();
        String prescribedMedicine = prescribedMedicineTextField.getText();

        String sql = "INSERT INTO medical_history(Symptoms, Date, PrescribledMedicine) VALUES(?,?,?)";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:src/database/HealthAppDB.db"); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, symptoms);
            pstmt.setString(2, date);
            pstmt.setString(3, prescribedMedicine);

            pstmt.executeUpdate();

            System.out.println("Data added to the database.");

            // Refresh the table (if required)
            model2.addRow(new Object[]{symptoms, date, prescribedMedicine});
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }//GEN-LAST:event_addMtablerowActionPerformed

    private void prescribedMedicineTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_prescribedMedicineTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_prescribedMedicineTextFieldActionPerformed

    private void deleteMtablerowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteMtablerowActionPerformed
        // TODO add your handling code here:
        int selectedRow = mtable.getSelectedRow();

        if (selectedRow == -1) {
            System.out.println("No row selected.");
            return;
        }

        int id = (int) model2.getValueAt(selectedRow, 0); // Assuming ID is the first column

        String sql = "DELETE FROM medical_history WHERE ID = ?";

        try (Connection conn = DriverManager.getConnection("jdbc:sqlite:src/database/HealthAppDB.db"); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, id);

            pstmt.executeUpdate();

            System.out.println("Data deleted from the database.");

            // Remove the selected row from the table model
            model2.removeRow(selectedRow);
        } catch (SQLException e) {
            System.out.println("Error deleting data: " + e.getMessage());
        }

    }//GEN-LAST:event_deleteMtablerowActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addMtablerow;
    private javax.swing.JButton addRowButton;
    private com.toedter.calendar.JDateChooser dateTextField;
    private javax.swing.JButton deleteMtablerow;
    private javax.swing.JButton deleteRowButton;
    private javax.swing.JTextField diseaseNameTextField2;
    private javax.swing.JTextField generationTextFIeld;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable mtable;
    private javax.swing.JTextField prescribedMedicineTextField;
    private javax.swing.JTextField relationTextField;
    private javax.swing.JTextField symptomsTextField;
    // End of variables declaration//GEN-END:variables
}
