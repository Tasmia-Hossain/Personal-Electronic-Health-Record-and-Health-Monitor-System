package healthapp;

import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import static javax.swing.JOptionPane.showMessageDialog;
import java.util.prefs.Preferences;

public class Login extends javax.swing.JFrame {

    public Login() {
        initComponents();
        Preferences prefs = Preferences.userNodeForPackage(Login.class);
        boolean keepSignedIn = prefs.getBoolean("keepSignedIn", false); // Default to false if not found

// Set the checkbox state based on the retrieved preference
        keepMeSignedInCheckBox.setSelected(keepSignedIn);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        Right = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        Left = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        usernameTextField = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        passwordTextField = new javax.swing.JPasswordField();
        loginButton = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        registerPageButton = new javax.swing.JButton();
        showOrHidePasswordButton = new javax.swing.JButton();
        forgetPasswordButton = new javax.swing.JButton();
        keepMeSignedInCheckBox = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Welcome!");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setPreferredSize(new java.awt.Dimension(800, 500));
        jPanel1.setLayout(null);

        Right.setBackground(new java.awt.Color(19, 95, 249));
        Right.setPreferredSize(new java.awt.Dimension(400, 500));

        jLabel6.setFont(new java.awt.Font("Malgun Gothic Semilight", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("<html> Personal Electronic Health Record<br>  &nbsp (EHR) & Health Monitor System </html>");

        jLabel7.setFont(new java.awt.Font("Segoe UI Light", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(204, 204, 204));
        jLabel7.setText("Your Virtual Guide");

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/FF.png"))); // NOI18N
        jLabel9.setText("jLabel9");

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Medi Tracker");

        javax.swing.GroupLayout RightLayout = new javax.swing.GroupLayout(Right);
        Right.setLayout(RightLayout);
        RightLayout.setHorizontalGroup(
            RightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RightLayout.createSequentialGroup()
                .addGroup(RightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(RightLayout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 298, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, RightLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addContainerGap(30, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, RightLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(RightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, RightLayout.createSequentialGroup()
                        .addComponent(jLabel7)
                        .addGap(129, 129, 129))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, RightLayout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(108, 108, 108))))
        );
        RightLayout.setVerticalGroup(
            RightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(RightLayout.createSequentialGroup()
                .addGroup(RightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(RightLayout.createSequentialGroup()
                        .addGap(356, 356, 356)
                        .addComponent(jLabel5))
                    .addGroup(RightLayout.createSequentialGroup()
                        .addGap(50, 50, 50)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(29, 29, 29)
                        .addComponent(jLabel8)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 61, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jLabel7)
                .addContainerGap(51, Short.MAX_VALUE))
        );

        jLabel6.getAccessibleContext().setAccessibleName("");

        jPanel1.add(Right);
        Right.setBounds(0, 0, 370, 500);

        Left.setBackground(new java.awt.Color(255, 255, 255));
        Left.setMinimumSize(new java.awt.Dimension(400, 500));

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 102));
        jLabel1.setText("LOGIN");

        jLabel2.setBackground(new java.awt.Color(102, 102, 102));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel2.setText("Username");

        usernameTextField.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        usernameTextField.setForeground(new java.awt.Color(102, 102, 102));

        jLabel3.setBackground(new java.awt.Color(102, 102, 102));
        jLabel3.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        jLabel3.setText("Password");

        loginButton.setBackground(new java.awt.Color(0, 102, 102));
        loginButton.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        loginButton.setForeground(new java.awt.Color(255, 255, 255));
        loginButton.setText("Login");
        loginButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                loginButtonActionPerformed(evt);
            }
        });

        jLabel4.setText("Don't have an account?");

        registerPageButton.setBackground(new java.awt.Color(0, 102, 102));
        registerPageButton.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        registerPageButton.setForeground(new java.awt.Color(255, 255, 255));
        registerPageButton.setText("Register");
        registerPageButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                registerPageButtonActionPerformed(evt);
            }
        });

        showOrHidePasswordButton.setForeground(new java.awt.Color(255, 255, 255));
        showOrHidePasswordButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/image/show pass.png"))); // NOI18N
        showOrHidePasswordButton.setToolTipText("");
        showOrHidePasswordButton.setContentAreaFilled(false);
        showOrHidePasswordButton.setFocusPainted(false);
        showOrHidePasswordButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                showOrHidePasswordButtonActionPerformed(evt);
            }
        });

        forgetPasswordButton.setText("Forget Password?");
        forgetPasswordButton.setContentAreaFilled(false);
        forgetPasswordButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                forgetPasswordButtonActionPerformed(evt);
            }
        });

        keepMeSignedInCheckBox.setText("Keep Me Signed in");
        keepMeSignedInCheckBox.setContentAreaFilled(false);
        keepMeSignedInCheckBox.setFocusPainted(false);
        keepMeSignedInCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keepMeSignedInCheckBoxActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout LeftLayout = new javax.swing.GroupLayout(Left);
        Left.setLayout(LeftLayout);
        LeftLayout.setHorizontalGroup(
            LeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LeftLayout.createSequentialGroup()
                .addGroup(LeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(LeftLayout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(LeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addGroup(LeftLayout.createSequentialGroup()
                                .addGroup(LeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, LeftLayout.createSequentialGroup()
                                        .addComponent(loginButton, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 89, Short.MAX_VALUE)
                                        .addComponent(forgetPasswordButton))
                                    .addComponent(usernameTextField, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(passwordTextField, javax.swing.GroupLayout.Alignment.LEADING))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(showOrHidePasswordButton, javax.swing.GroupLayout.PREFERRED_SIZE, 63, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(LeftLayout.createSequentialGroup()
                                .addGroup(LeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(keepMeSignedInCheckBox, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 136, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(registerPageButton))))
                    .addGroup(LeftLayout.createSequentialGroup()
                        .addGap(134, 134, 134)
                        .addComponent(jLabel1)))
                .addGap(0, 23, Short.MAX_VALUE))
        );
        LeftLayout.setVerticalGroup(
            LeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(LeftLayout.createSequentialGroup()
                .addGap(54, 54, 54)
                .addComponent(jLabel1)
                .addGap(37, 37, 37)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(usernameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(LeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(showOrHidePasswordButton, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(passwordTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                .addGroup(LeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(loginButton, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(forgetPasswordButton, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addGroup(LeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(registerPageButton))
                .addGap(18, 18, 18)
                .addComponent(keepMeSignedInCheckBox, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
        );

        jPanel1.add(Left);
        Left.setBounds(370, 0, 430, 500);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void registerPageButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_registerPageButtonActionPerformed

        SignUp SignUpFrame = new SignUp();
        SignUpFrame.setVisible(true);
        SignUpFrame.pack();
        SignUpFrame.setLocationRelativeTo(null);
        this.dispose();
    }//GEN-LAST:event_registerPageButtonActionPerformed

    private void loginButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_loginButtonActionPerformed
       System.out.println("Login Button pressed");
        String username, password, query, passdb = null;
        String dbPath = "jdbc:sqlite:src/database/HealthAppDB.db"; // SQLite database path

        int notFound = 0;

        try {
            Class.forName("org.sqlite.JDBC");

            Connection con;
            con = DriverManager.getConnection(dbPath);
            Statement st = con.createStatement();

            if ("".equals(usernameTextField.getText())) {
                JOptionPane.showMessageDialog(rootPane, "An Username Required!", "ERROR", JOptionPane.ERROR_MESSAGE);
            } else if ("".equals(passwordTextField.getPassword())) {
                JOptionPane.showMessageDialog(rootPane, "A Strong Password Required!", "ERROR", JOptionPane.ERROR_MESSAGE);
            } else {
                username = usernameTextField.getText();

                char[] passwordChars = passwordTextField.getPassword();
                password = new String(passwordChars);

                query = "SELECT * FROM SIGNUP WHERE Username='" + username + "'";
                ResultSet rs = st.executeQuery(query);

                while (rs.next()) {
                    passdb = rs.getString("password");
                    notFound = 1;
                }

                if (notFound == 1 && password.equals(passdb)) {
                    System.out.println("OK");

                    // Save the user's preference to keep signed in
                    Settings settings = new Settings();
                    if (keepMeSignedInCheckBox.isSelected()) {
                        settings.setKeepMeSignedIn(true);
                        settings.setLastLoggedInUsername(username);
                    } else {
                        settings.setKeepMeSignedIn(false);
                        settings.setLastLoggedInUsername("");
                    }

                    Dashboard DashboardFrame = new Dashboard(username);
                    DashboardFrame.setVisible(true);
                    DashboardFrame.pack();
                    DashboardFrame.setLocationRelativeTo(null);
                    this.dispose();
                } else {
                    JOptionPane.showMessageDialog(rootPane, "Incorrect Username or Password!", "ERROR", JOptionPane.ERROR_MESSAGE);
                }
                passwordTextField.setText("");
            }
        } catch (Exception e) {
            System.out.println("Error!" + e.getMessage());
        }
    }//GEN-LAST:event_loginButtonActionPerformed

    private void showOrHidePasswordButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_showOrHidePasswordButtonActionPerformed
        // TODO add your handling code here:
        char echoChar = passwordTextField.getEchoChar();

        // If the echo char is set to '*', change it to 0 (visible)
        // If the echo char is 0, change it to '*'
        if (echoChar == '•') {
            passwordTextField.setEchoChar((char) 0);
            showOrHidePasswordButton.setText("Hide");
        } else {
            passwordTextField.setEchoChar('•');
            showOrHidePasswordButton.setText("Show");
        }
    }//GEN-LAST:event_showOrHidePasswordButtonActionPerformed

    private void forgetPasswordButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_forgetPasswordButtonActionPerformed
        boolean emailFound = false;

        while (!emailFound) {
            // Display a dialog box to prompt the user for their email
            String userEmail = JOptionPane.showInputDialog(this, "Please enter your email:", "Forgot Password", JOptionPane.PLAIN_MESSAGE);

            // Check if the user input is not null (user didn't cancel the dialog)
            if (userEmail != null && !userEmail.isEmpty()) {
                try {
                    // Connect to the database
                    Class.forName("org.sqlite.JDBC");
                    // Prepare the SQL query
                    try (Connection conn = DriverManager.getConnection("jdbc:sqlite:src/database/HealthAppDB.db")) {
                        // Prepare the SQL query
                        String query = "SELECT Username, Email, Password FROM SIGNUP WHERE Email = ?";
                        try (PreparedStatement preparedStatement = conn.prepareStatement(query)) {
                            preparedStatement.setString(1, userEmail);

                            // Execute the query
                            ResultSet resultSet = preparedStatement.executeQuery();

                            // Check if the email is found in the database
                            if (resultSet.next()) {
                                String username = resultSet.getString("Username");
                                String email = resultSet.getString("Email");
                                String password = resultSet.getString("Password");

                                // Display the retrieved information
                                String message = "Username: " + username + "\n"
                                        + "Email: " + email + "\n"
                                        + "Password: " + password;

                                JOptionPane.showMessageDialog(this, message, "Password Recovery", JOptionPane.INFORMATION_MESSAGE);
                                emailFound = true; // Set the flag to true to exit the loop
                            } else {
                                // If email is not found
                                JOptionPane.showMessageDialog(this, "Email not found. Please check the entered email.", "Password Recovery", JOptionPane.WARNING_MESSAGE);
                            }

                            // Close connections
                            resultSet.close();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                // User canceled the dialog
                break; // Exit the loop if the user cancels
            }
        }
    }//GEN-LAST:event_forgetPasswordButtonActionPerformed

    private void keepMeSignedInCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keepMeSignedInCheckBoxActionPerformed
        // TODO add your handling code here:
        boolean keepSignedIn = keepMeSignedInCheckBox.isSelected();

        try {
            // Retrieve the user preferences node for the package of your class
            Preferences prefs = Preferences.userNodeForPackage(Login.class);

            // Use the preferences to store the user's preference
            prefs.putBoolean("keepSignedIn", keepSignedIn);

            // Optionally, display a message to confirm the change
            String message = keepSignedIn ? "You will be kept signed in." : "You will be signed out.";
            JOptionPane.showMessageDialog(this, message, "Sign In Preference", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_keepMeSignedInCheckBoxActionPerformed

    public void clearLoginInfo() {
        usernameTextField.setText("");
        passwordTextField.setText("");
        keepMeSignedInCheckBox.setSelected(false);
    }
    


    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Left;
    private javax.swing.JPanel Right;
    private javax.swing.JButton forgetPasswordButton;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JCheckBox keepMeSignedInCheckBox;
    private javax.swing.JButton loginButton;
    private javax.swing.JPasswordField passwordTextField;
    private javax.swing.JButton registerPageButton;
    private javax.swing.JButton showOrHidePasswordButton;
    private javax.swing.JTextField usernameTextField;
    // End of variables declaration//GEN-END:variables
}
